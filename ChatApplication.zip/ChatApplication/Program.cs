﻿using RabbitMQ.Client;
//Using RabbitMQ.Client; This line imports the necessary namespace RabbitMQ.Client which contains classes and interfaces for interacting with RabbitMQ in .NET applications.
using RabbitMQ.Client.Events;
using System.Text;

namespace ChatApplication
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Chat Room!");
            Console.WriteLine("If you wish to exit the Chat Room, please simply type E and press Enter.");
            //ConnectionFactory Initialization: Creates an instance of the ConnectionFactory class with the HostName property set to “localhost”, UserName and Password property set to "guest".
            var factory = new ConnectionFactory()
            {
                HostName = "localhost",
                UserName = "guest",
                Password = "guest"
            };
            //Connection Establishment:
            /*Establishes a connection to RabbitMQ using the created factory.
            Creates a channel from the connection to interact with RabbitMQ.
            Exchange Declaration:Declares an exchange named “room” of type Topic.This step sets up an exchange for broadcasting messages to all queues bound to it.*/
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                // Declare Exchange
                channel.ExchangeDeclare(exchange: "room", ExchangeType.Topic);
                //This line of code declares a new queue on the RabbitMQ server using the channel.QueueDeclare() method.
                var queueName = channel.QueueDeclare(queue: "room", durable: false, exclusive: false, autoDelete: false, arguments: null).QueueName;
                //After declaring the queue, this code binds the queue (queueName) to an exchange named “room” with a routing key named "room".
                channel.QueueBind(queueName, "room", routingKey: "");
                //Here, a new instance of EventingBasicConsumer is created, which is used for consuming messages from a queue asynchronously.
                var consumer = new EventingBasicConsumer(channel);
                //This part sets up an event handler for when a message is received by the consumer. 
                consumer.Received += (model, ea) =>
                /*Inside the lambda expression:
                var body = ea.Body.ToArray();: Extracts the message body as a byte array.
                var message = Encoding.UTF8.GetString(body);: Converts the byte array to a UTF-8 encoded string.
                Console.WriteLine($"[Received] {message}");: Outputs the received message to the console with a prefix “[Received]”.*/
                {
                    var body = ea.Body.ToArray();
                    var message = Encoding.UTF8.GetString(body);
                    Console.WriteLine("-");
                    Console.WriteLine($"[Received] {message}");
                    Console.WriteLine("-");
                    Console.WriteLine("Queue and Exchange created successfully.");
                    Console.WriteLine("-");
                };
                /*This method is used to start consuming messages from a specific queue.*/
                channel.BasicConsume(queue: queueName, true, consumer: consumer);
                /*The program first prompts the user to enter their username using Console.WriteLine("Enter your username:") and reads the input into the username variable.*/
                Console.WriteLine("Enter your username:");
                string username = Console.ReadLine()!;
                /**/
                while (true)
                {
                    Console.WriteLine("Press enter to send a message");
                    Console.WriteLine("-");
                    Console.WriteLine("Enter message: ");
                    Console.WriteLine("-");
                    string message = Console.ReadLine()!;
                    /*The program encodes the message along with the username in UTF-8 format using Encoding.UTF8.GetBytes($"[{username}]: {message}").*/
                    var body = Encoding.UTF8.GetBytes($"[{username}]: {message}");
                    /*Finally, it publishes this message to an exchange named “room” with an empty routing key using channel.BasicPublish(exchange: "room", routingKey: "", basicProperties: null, body: body).*/
                    channel.BasicPublish(exchange: "room", routingKey: "", basicProperties: null, body: body);
                    if (message.ToLower() == "e")
                    {
                        break; // Exit the loop if user types 'e'
                    }
                }
            }
        }
    }
}